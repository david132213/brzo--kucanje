let word =document.getElementById('word');
let text =document.getElementById('text');
let scoreEl =document.getElementById('score');
let timeEl =document.getElementById('time');
let endgameEl =document.getElementById('end-game-container');

words=[
 'dismiss',
'nose',
'tumble',
'government',
'fund',
'barrier',
'attention',
'fist',
'apple',
'reckless',
'texture',
'thread',
'bomber',
'extraterrestrial',
'magnitude',
'shy',
'memory',
'time',
'imperial',
'agree'
]

let randomWord = '';
let score = 0;
let time = 10;

let timeInterval = setInterval(updateTime, 1000);
function gameOver(){
    endgameEl.innerHTML =`<h1>vreme je iteklo</h1>
                          <p>finalni rezultat je ${score}</p>
                          <button onclick= "location.reload()">probajte poonovo</button>`;
endgameEl.style.display='flex'}

function getRandomWords() {
    randomNumber = Math.floor(Math.random() * words.length);
    return words[randomNumber];
}
function placeRandomWord() {
    randomWord = getRandomWords();
    word.innerText = randomWord;
}



function updateTime() {
    time--

    timeEl.innerText = time+'s';
    if(time == 0) {
        clearInterval(timeInterval);
        gameOver();
    
    }
}
function updateScore(){
   score++
   scoreEl.innerText=score        
}


placeRandomWord() 

 text.addEventListener('input',e=> {
    insertedText = e.target.value;

    if(insertedText == randomWord){
        placeRandomWord()
        updateScore();

        text.value='';

        time+=3
        updateTime();
    }
    
})

